#include "light.h"
#include "phong_shader.h"
#include "ray.h"
#include "render_world.h"
#include "object.h"

vec3 Phong_Shader::
Shade_Surface(const Ray& ray,const vec3& intersection_point,
    const vec3& normal,int recursion_depth) const
{
    vec3 color;
    //TODO; determine color
    color = color_ambient * world.ambient_color * world.ambient_intensity;
    for(unsigned int i = 0; i < world.lights.size(); i++)
    {
        vec3 l = (world.lights.at(i)->position - intersection_point).normalized();
        vec3 r = (2 * dot(l, normal) * normal - l).normalized();
        vec3 light_at_here = world.lights.at(i)->Emitted_Light(world.lights.at(i)->position - intersection_point);
        double d = std::max(0.00, dot(l, normal));
        double s = pow(std::max(0.00, dot(r, (ray.endpoint - intersection_point).normalized())), specular_power);
        color = color + light_at_here * (color_diffuse * d + color_specular * s);
    }
    return color;
    //return world.lights[0]->Emitted_Light(l);
}
