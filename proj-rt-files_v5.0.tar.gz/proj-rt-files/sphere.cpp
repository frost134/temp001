#include "sphere.h"
#include "ray.h"

// Determine if the ray intersects with the sphere
Hit Sphere::Intersection(const Ray& ray, int part) const
{
    //TODO;
    vec3 origin_to_center = center - ray.endpoint;
    double project_o_t_c = dot(ray.direction,origin_to_center);
    if (project_o_t_c < small_t)
    {
        return {0,0,0};
    }
    if ((dot(origin_to_center,origin_to_center)-project_o_t_c*project_o_t_c)>radius*radius)
    {
        return {0,0,0};
    }
    double discriminant = sqrt(radius*radius-(dot(origin_to_center,origin_to_center)-project_o_t_c*project_o_t_c));
    return {this,project_o_t_c - discriminant,part};
}

vec3 Sphere::Normal(const vec3& point, int part) const
{
    vec3 normal;
    //TODO; // compute the normal direction
    normal = (point - center).normalized();
    return normal;
}

Box Sphere::Bounding_Box(int part) const
{
    Box box;
    TODO; // calculate bounding box
    return box;
}
